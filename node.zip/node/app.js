var math = require('mathlib')();     //notice the extra invocation parentheses!
console.log(math.add(2,3))

console.log(math.multiply(2,3))

console.log(math.square(5))

console.log(math.random(1,35))
